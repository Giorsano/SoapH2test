package com.example.SoapDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoapDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
