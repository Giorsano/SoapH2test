package com.example.SoapDB;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;
import java.sql.DriverManager;

@Configuration
public class JdbcConfig {

    @Bean
    public DataSource dataSource(){
        DriverManagerDataSource driverManager = new DriverManagerDataSource(); // classe Spring per creare connessioni al DB
        driverManager.setDriverClassName("org.h2.Driver"); //imposta il nome del driver di H2
        driverManager.setUrl("jdbc:h2:file:./prova"); //importa l'URL di H2 (ovvero il JDBC, che cambia per ogni db)
        driverManager.setUsername("sa"); //username del db
        driverManager.setPassword(""); // password del DB
        return driverManager; //ritorno dell'oggetto del collegamento
    }
}
