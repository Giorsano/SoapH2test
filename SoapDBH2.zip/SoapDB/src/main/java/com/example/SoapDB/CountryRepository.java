package com.example.SoapDB;

import gs_producing_web_service.Country;
import gs_producing_web_service.Currency;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.*;
import java.util.PropertyPermission;


@Repository
public class CountryRepository {

    @Autowired
    DataSource dataSource;

    @PostConstruct
    public void initData() {

        Country spain = new Country();
        spain.setCapital("Madrid");
        spain.setName("Spain");
        spain.setCurrency(Currency.EUR);
        spain.setPopulation(565151);
        insertCountry(spain);

        Country poland = new Country();
        poland.setCapital("Warsaw");
        poland.setName("Poland");
        poland.setCurrency(Currency.PLN);
        poland.setPopulation(656151);


        Country uk = new Country();
        uk.setCapital("London");
        uk.setName("United Kingdom");
        uk.setCurrency(Currency.GBP);
        uk.setPopulation(152321);
        insertCountry(uk);

    }


    public void createTable(){
        String sql = "CREATE TABLE countries (name VARCHAR(255), capital VARCHAR(255), currency VARCHAR(255), population INTEGER)";
        try(Connection connection = dataSource.getConnection()){
            Statement statement = connection.createStatement();
            statement.executeUpdate(sql);
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
 /*
 Il PreparedStatement è un'interfaccia fornita da JDBC per eseguire query precompilate, quindi puoi creare una query ed eseguirla
 con parametri differenti
 Connection è di JDBC e serve a creare una connesione con il db.
 Ricorda che le connessioni fanno sempre messe in un try e catch.
 Lo Statement è un interfaccia che serve ad eseguire le istruzioni SQL come modifica, creazione ecc..
 Sia lo statement che la connection sono due oggetti che vanno creati. Il primo va preso attraverso il getconnection della
 configurazione, il secondo invece lo crei attraverso l'oggetto connection.
 La differenza tra Statement e Prepared Statement è che lo statment serve per eseguire una sola volta una query non precompilata
 Il prepared Statement come detto, esegue invece, una query precompilata PIU volte con valori differenti
 */


    public void insertCountry(Country country){
        String sql = "INSERT INTO countries (name, capital, currency, population) VALUES (?, ?, ?, ?)";
        try(Connection connection = dataSource.getConnection()){
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, country.getName());
            preparedStatement.setString(2, country.getCapital());
            preparedStatement.setString(3, country.getCurrency().toString());
            preparedStatement.setInt(4, country.getPopulation());
            preparedStatement.executeUpdate();
        } catch(SQLException e) {
            e.printStackTrace();
        }
    }


    public Country getCountryByName(String name){
    String sql = "SELECT * FROM countries WHERE name = ?";
    try(Connection connection = dataSource.getConnection()){
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, name);
        ResultSet resultSet = preparedStatement.executeQuery();
        // ResultSet è un'interfaccia JDBC che serve a rappresentare un risultato di una query, eseguita su un DB.
        if(resultSet.next()){
            Country country = new Country();
            country.setName(resultSet.getString("name"));
            country.setCapital(resultSet.getString("capital"));
            country.setCurrency(Currency.valueOf(resultSet.getString("currency")));
            country.setPopulation(resultSet.getInt("population"));
            return country;
        }
    } catch (SQLException e){
        e.printStackTrace();
    }
    return null; //qui è considerato l'else dell'if, infatti il result ritorna una country (vedi if)
        //oppure nulla se non lo trova.
    }


    /*
    Prassi constatata per ogni query:
    1 - creare una stringa contenente la query
    2 - aprire un try dove nelle parentesi () apri una connessione con Connection nomeConnessione = classeConfigurazione.getConnection()
    3 - Apri le graffe e dentro metti un oggetto Statement se si tratta di una query non precompilata da svolgere UNA volta,
        oppure PreparedStament se è una Query precompilata da eseguire PIU volte con valori differenti.
        ps: i valori differenti sono rappresentati nella query con il simbolo ?.
    4 - La sintassi è: PreparedStatment nomeStatement = connection.prepareStatment(nomeStringaQuery)
        Per lo statment normale sarà: Statment nomeStatement = connection.Statment()
     */
}
